SourceSpool v0.1.0 posting kit

Start with docs/launch-kit/README.md.
Captions: docs/launch-kit/*.txt
Screenshots: docs/demo/*.png (six steps plus one light alternative)
Optional video: docs/demo/sourcespool-demo.mp4

The owner handles social publication. Images are annotated renders of captured production terminal text, using original locally served media. Existing local assets were reused; no media, tools or packages were downloaded to assemble this kit.
