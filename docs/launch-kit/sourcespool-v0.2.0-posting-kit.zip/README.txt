SourceSpool v0.2.0 posting kit
Start with docs/launch-kit/README.md. The owner publishes independently. Historical v0.1.0 visuals illustrate the library workflow.
