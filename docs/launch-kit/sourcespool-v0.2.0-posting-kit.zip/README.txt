SourceSpool v0.2.0 posting kit
Start with docs/launch-kit/README.md. Workflow captures: v0.2.0 development checkout, 2026-10-18T09:29:05.674Z. The owner publishes independently.
